document.getElementById("para").onclick = function() {  
    fun()
};  
function fun() {   
    document.getElementById("para").style.color = "blue";  
    document.getElementById("para").style.backgroundColor = "yellow";  
    document.getElementById("para").style.fontSize = "25px";  
    document.getElementById("para").style.border = "4px solid red";   
}

document.addEventListener("DOMContentLoaded", () => {
    console.log("Hello World!");
});